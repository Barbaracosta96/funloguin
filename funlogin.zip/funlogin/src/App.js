import "./App.css";
// import LeftNavBar from "./components/LeftNavBar/LeftNavBar";
// import TopNavBar from "./components/TopNavBar/TopNavBar";
// import Dashboard from "./Pages/Dashboard/Dashboard";
// import CashIn from "./Pages/Cash In/CashIn";
// import CashOut from './Pages/Cash Out/CashOut';
// import InsencaoTaxa from "./Pages/InsencaoTaxa/InsencaoTaxa";
// import Contas from "./Pages/Contas/Contas";

import AppRouter from "./AppRouter";

function App() {
  return (
    <div>
      {/* Use o componente AppRouter para renderizar as páginas com base nas rotas */}
      <AppRouter />
    </div>
  );
}

export default App;
