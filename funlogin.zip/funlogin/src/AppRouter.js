import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Dashboard from './Pages/Dashboard/Dashboard';
import Contas from './Pages/Contas/Contas';
import CashIn from './Pages/Cash In/CashIn';
import CashOut from  './Pages/Cash Out/CashOut';
import InsencaoTaxa from './Pages/InsencaoTaxa/InsencaoTaxa';
import Password from "./Pages/Password/Password";
import UserConfig from './Pages/User config/UserConfig';
import TopNavBar from './components/TopNavBar/TopNavBar';


function AppRouter() {
  return (
    <Router>
      <TopNavBar />
      <Routes>
        <Route path='/' element={<Dashboard />} />
        <Route path="/Contas" element={<Contas />} />
        <Route path="/CashIn" element={<CashIn />} />
        <Route path="/CashOut" element={<CashOut />} />
        <Route path="/InsencaoTaxa" element={<InsencaoTaxa />} />
        <Route path='/Password' element={<Password />} />
        <Route path='/UserConfig' element={<UserConfig />} />
      </Routes>

    </Router>
  );
}

export default AppRouter;
