
import React, { useState } from 'react';
import '../../App.css';


function CashIn() {
  const [data, setData] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');

  // Função para adicionar dados de exemplo (você pode carregar dados de uma API)
  const addData = () => {
    setData((prevData) => [
      ...prevData,
      {
        id: prevData.length + 1,
        name: `Item ${prevData.length + 1}`,
        description: `Descrição do item ${prevData.length + 1}`,
      },
    ]);
  };

  return (

    <div className='wrapper'>
      <div className='search-div'>
      <h3>Cash In</h3>
      <input
        className='input-search'
        style={{margin:'30px 0'}}
        type="text"
        placeholder="Pesquisar"
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
      />
      <button className='input-icon' onClick={addData}><i class="fa-solid fa-magnifying-glass white-color"></i></button>

      </div>
      
      <table className="table">
        <thead>
          <tr>
            <th>USUÁRIO</th>
            <th>DATA</th>
            <th>TIPO</th>
            <th>STATUS</th>
            <th>TOTAL</th>
            <th>LÍQUIDO</th>
            <th>AÇÕES</th>
          </tr>
        </thead>
        <tbody>
          {data
            .filter((item) =>
              item.name.toLowerCase().includes(searchQuery.toLowerCase())
            )
            .map((item) => (
              <tr key={item.USUÁRIO}>
                <td>{item.id}</td>
                <td>{item.name}</td>
                <td>{item.description}</td>
              </tr>
            ))}
        </tbody>
      </table>
    </div>
  );
}

export default CashIn;
