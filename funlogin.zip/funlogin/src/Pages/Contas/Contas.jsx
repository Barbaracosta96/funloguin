

import React, { useState } from 'react';
import '../../App.css';


function Contas() {
  const [data, setData] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');

  // Função para adicionar dados de exemplo (você pode carregar dados de uma API)
  const addData = () => {
    setData((prevData) => [
      ...prevData,
      {
        id: prevData.length + 1,
        name: `Item ${prevData.length + 1}`,
        description: `Descrição do item ${prevData.length + 1}`,
      },
    ]);
  };

  return (

    <div className='wrapper'>
      <div className='search-div'>
      <h3>Todas Contas</h3>
      <input
        className='input-search'
        style={{marginTop:'30px'}}
        type="text"
        placeholder="Pesquisar"
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
      />
      <button className='input-icon' onClick={addData}><i class="fa-solid fa-magnifying-glass white-color"></i></button>
      <button style={{marginLeft:'100px',width:'200px',height:'60px',color:'white',backgroundColor:"black",borderRadius:'10px'}}>Nova Conta</button>
        <br></br>
      <input
        className='input-search'
        style={{margin:'10px 0px 20px'}}
        type="text"
        placeholder="Pesquisar"
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
      />
      <button className='input-icon' onClick={addData}><i class="fa-solid fa-magnifying-glass white-color"></i></button>

      </div>
      <table className="table">
        <thead>
          <tr>
            <th>DATA</th>
            <th>NOME</th>
            <th>LOGIN</th>
            <th>DOCUMENTO</th>
            <th>SAQUES TOTAIS</th>
            <th>STATUS</th>
          </tr>
        </thead>
        <tbody>
          {data
            .filter((item) =>
              item.name.toLowerCase().includes(searchQuery.toLowerCase())
            )
            .map((item) => (
              <tr key={item.USUÁRIO}>
                <td>{item.id}</td>
                <td>{item.name}</td>
                <td>{item.description}</td>
              </tr>
            ))}
        </tbody>
      </table>
    </div>
  );
}

export default Contas;
