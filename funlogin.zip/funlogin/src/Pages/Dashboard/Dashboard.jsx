
import Saldo from "../../components/Saldo/Saldo";
import "./Dashboard.css";

function Dashboard() {
  return (
    <div className="wrapper">
            <div className="Dashboard ">
        {/* <h1 className="color-black">Dashboard</h1> */}
        <Saldo />
        <div className="row">
          <div className="col-sm-4">
            <div className="container bg-blue cards">
              <h3>Total de Contas</h3>
              <div className="container cards-content">
                <span>
                  <strong>Criadas: 99</strong>
                </span>
                <br></br>
                <span>
                  <strong>Regulares: 77</strong>
                </span>
              </div>
            </div>
          </div>
          <div className="col-sm-4">
            <div className="container bg-blue cards">
              <h3>
                Novas Contas <br></br>
              </h3>
              <span>(últimos 30 dias)</span>
              <div className="container cards-content">
                <p>
                  <strong>66</strong>
                </p>
              </div>
            </div>
          </div>
          <div className="col-sm-4">
          <div className="container bg-blue cards circle">
            <h3>Cash-In</h3>
            <div className="container cards-content">
              <p>
                <strong>R$ 52.773,09</strong>
              </p>
            </div>
          </div>
        </div>
        </div>
       
        <div className="row">
          <div className="col-sm-4">
            <div className="container bg-blue cards circle">
              <h3>Cash-out</h3>
              <div className="container cards-content">
                <p>
                  <strong>R$ 51.062,91</strong>
                </p>
              </div>
            </div>
          </div>

          <div className="col-sm-4">
            <div className="container bg-blue cards circle">
              <h3>Consultas CPF Total</h3>
              <div className="container cards-content">
                <p>
                  <strong>145</strong>
                </p>
              </div>
            </div>
          </div>
          <div className="col-sm-4">
            <div className="container bg-blue cards circle">
              <h3>
                Consultas CPF <br></br>
              </h3>
              <span>(últimos 30 dias)</span>
              <div className="container cards-content">
                <p>
                  <strong>89</strong>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
        </div>
  );
}

export default Dashboard;
