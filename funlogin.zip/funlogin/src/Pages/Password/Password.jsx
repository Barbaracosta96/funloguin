
import './Password.css'

function Password(){
    return(
        <div className="wrapper">
        <div className="Password">
            <h3><strong>Alterar Senha</strong></h3>
            <p>Ao clicar em "ALTERAR", será enviado um link de redefinição de <br></br>
                senha no seu email. Basta clicar nele e seguir as instruções.</p>

            <button>ALTERAR</button>
            <button>CANCELAR</button>
        </div>

    </div>
    )
   
}


export default Password;