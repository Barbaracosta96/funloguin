import "./UserConfig.css";

function UserConfig() {
  return (
    <div className="wrapper ">
      <div className="UserConfig-input">
        <h3>Configuração do Usuário</h3>
        <div>
          <label>
            <strong>Nº da Conta</strong>
          </label>
          <div className="input">
            <p>5516584494997965445</p>
          </div>
          <label>
            <strong>Informações</strong>
          </label>
          <div className="input">
            <p>ANTHONY ALFONSO MIRANDA</p>
          </div>
          <label>
            <strong>CPF*</strong>
          </label>
          <div className="input">
            <p>999.999.999-99</p>
          </div>
        </div>

        <div className="UserConfig-pix">
          <p>
            <strong>Situação</strong>
          </p>
          <div class="container text-center">
            <div class="row">
              <div class="col">
                <button className="desativado">
                  <strong>Desativado</strong>
                </button>
              </div>
              <div class="col">
                <button className="ativar-pix">
                  <strong>ATIVAR (chave pix CPF)</strong>
                </button>
              </div>
              <div class="col">
                <button className="ativar-pix">
                  <strong>ATIVAR (chave pix ALEATORIA)</strong>
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="UserConfig-extrato">
          <h5><strong>Extrato</strong></h5>
          <table className="table">
            <thead>
              <tr>
                <th>USUÁRIO</th>
                <th>DATA</th>
                <th>TIPO</th>
                <th>STATUS</th>
                <th>TOTAL</th>
                <th>LIQUIDO</th>
                <th>AÇÕES</th>
              </tr>
            </thead>
            <tbody>
              {/* {data
            .filter((item) =>
              item.name.toLowerCase().includes(searchQuery.toLowerCase())
            )
            .map((item) => (
              <tr key={item.USUÁRIO}>
                <td>{item.id}</td>
                <td>{item.name}</td>
                <td>{item.description}</td>
              </tr>
            ))} */}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default UserConfig;
