
import { Link } from "react-router-dom";
import './Saldo.css'

function Saldo(){
    return(
       <div className="main text-center">
        <ul className="navbar-nav d-flex flex-row justify-content-center" >
            <li className="nav-item">
            <a className="nav-link saldo" >Saldo R$ 0,01 
            <i className='fas fa-rotate' onClick={() => {
            alert('clicked')
          }}></i></a>
            </li>
            <li className="nav-item">
              <Link to="/UserConfig" className='nav-link nav-button saldo' style={{textDecoration:'underline'}} onClick={
              ()=>{
                document.querySelectorAll('.nav-button').forEach(link => {
                  link.classList.remove('active');
                });
              }
            }>Acessar Conta Mãe</Link>
            </li>
          </ul>
       </div>
    )
}

export default Saldo;