
import { Link } from 'react-router-dom'
import './TopNavBar.css'
import logo from '../../assets/fun-nobg.png'


function TopNavBar() {
  return (
    <nav className="navbar bg-blue fixed-left ">
      
      <img className="" src={logo} ></img>


      <div className="" id="navbarNav">
        <ul className="navbar-nav d-flex flex-row ">
          <li className="nav-item">
            <Link className="nav-link nav-button active dashboard" onClick={
              (event)=>{
                document.querySelectorAll('.nav-button').forEach(link => {
                  link.classList.remove('active');
                });
                event.target.classList.add('active');
              }
            } to='/'>Dashboard</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link nav-button" onClick={
              (event)=>{
                document.querySelectorAll('.nav-button').forEach(link => {
                  link.classList.remove('active');
                });
                event.target.classList.add('active');
              }
            } to='/Contas'>Contas</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link nav-button" onClick={
              (event)=>{
                document.querySelectorAll('.nav-button').forEach(link => {
                  link.classList.remove('active');
                });
                event.target.classList.add('active');
              }
            } to='/CashIn'>Cash In</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link nav-button" onClick={
              (event)=>{
                document.querySelectorAll('.nav-button').forEach(link => {
                  link.classList.remove('active');
                });
                event.target.classList.add('active');
              }
            } to='/CashOut'>Cash Out</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link nav-button" onClick={
              (event)=>{
                document.querySelectorAll('.nav-button').forEach(link => {
                  link.classList.remove('active');
                });
                event.target.classList.add('active');
              }
            } to='/InsencaoTaxa'>Insenção de Taxa</Link>
          </li>
        </ul>
      </div>
      
      
      <div>
      <i className='fas fa-user' onClick={() => {
            document.querySelector('.dropdown-content').classList.toggle('hidden')
          }}></i>
          
          <div className='dropdown-content hidden'>
          <p className='text-center'><strong>User:</strong> bebis7455@gmail.com</p>
            <Link to="/Password" className='btn btn-lg' onClick={
              ()=>{
                document.querySelectorAll('.nav-button').forEach(link => {
                  link.classList.remove('active');
                });
              }
            }>ALTERAR</Link>
            <Link to="" className='btn btn-lg' onClick={
              ()=>{
                document.querySelectorAll('.nav-button').forEach(link => {
                  link.classList.remove('active');
                });
              }
            } >SAIR</Link>
            
          </div>
          </div>
    </nav>
    )
}

export default TopNavBar;
